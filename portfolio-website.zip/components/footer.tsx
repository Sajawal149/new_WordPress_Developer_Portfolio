"use client"

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const footerLinks = [
    {
      title: "Navigation",
      links: [
        { label: "Home", href: "#hero" },
        { label: "About", href: "#about" },
        { label: "Services", href: "#services" },
      ],
    },
    {
      title: "Services",
      links: [
        { label: "WordPress Development", href: "#services" },
        { label: "WooCommerce Setup", href: "#services" },
        { label: "SEO Optimization", href: "#services" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Privacy Policy", href: "#" },
        { label: "Terms of Service", href: "#" },
        { label: "Contact", href: "#contact" },
      ],
    },
  ]

  const handleClick = (href: string) => {
    const sectionId = href.replace("#", "")
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <footer className="relative border-t border-white/10 bg-gradient-to-b from-background to-background/50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Main Footer Content */}
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="space-y-4">
              <a
                href="#hero"
                onClick={(e) => {
                  e.preventDefault()
                  handleClick("#hero")
                }}
                className="flex items-center gap-2 group"
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg group-hover:shadow-lg group-hover:shadow-purple-500/50 transition-all">
                  WP
                </div>
                <span className="font-bold text-lg bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  WordPress Dev
                </span>
              </a>
              <p className="text-foreground/60 text-sm">
                Creating beautiful, high-performance WordPress websites that deliver results.
              </p>
            </div>

            {/* Footer Links */}
            {footerLinks.map((group, index) => (
              <div key={index} className="space-y-4">
                <h4 className="font-semibold text-white">{group.title}</h4>
                <ul className="space-y-2">
                  {group.links.map((link, i) => (
                    <li key={i}>
                      <a
                        href={link.href}
                        onClick={(e) => {
                          e.preventDefault()
                          handleClick(link.href)
                        }}
                        className="text-foreground/60 hover:text-foreground/90 transition-colors text-sm"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-white/20 to-transparent mb-8" />

          {/* Bottom Footer */}
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-foreground/60 text-sm text-center md:text-left">
              &copy; {currentYear} WordPress Developer. All rights reserved.
            </p>
            <div className="flex gap-4 mt-4 md:mt-0">
              <a href="#" className="text-foreground/60 hover:text-foreground/90 transition-colors text-sm">
                Privacy
              </a>
              <span className="text-foreground/30">•</span>
              <a href="#" className="text-foreground/60 hover:text-foreground/90 transition-colors text-sm">
                Terms
              </a>
              <span className="text-foreground/30">•</span>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault()
                  handleClick("#contact")
                }}
                className="text-foreground/60 hover:text-foreground/90 transition-colors text-sm"
              >
                Contact
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
