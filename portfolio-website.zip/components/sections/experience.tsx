"use client"

import { useEffect, useRef, useState } from "react"

const Experience = () => {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.3 },
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const experiences = [
    {
      title: "Senior WordPress Developer",
      company: "Digital Solutions Inc.",
      period: "2022 - Present",
      description:
        "Led development of 15+ enterprise WordPress projects. Managed team of 3 developers, implemented best practices, and achieved 99.9% uptime.",
      responsibilities: [
        "Built custom themes and plugins for Fortune 500 clients",
        "Optimized website performance (45% improvement)",
        "Implemented security protocols and compliance standards",
      ],
    },
    {
      title: "WordPress Developer",
      company: "Creative Web Studios",
      period: "2020 - 2022",
      description:
        "Developed and maintained WordPress sites for small and mid-sized businesses. Specialized in WooCommerce e-commerce solutions.",
      responsibilities: [
        "Created 20+ custom WordPress websites",
        "Managed WooCommerce stores with $2M+ annual revenue",
        "Provided ongoing maintenance and support",
      ],
    },
    {
      title: "Junior Web Developer",
      company: "TechStart Agency",
      period: "2019 - 2020",
      description:
        "Started my web development career learning WordPress fundamentals and best practices in a collaborative environment.",
      responsibilities: [
        "Assisted in WordPress theme development",
        "Fixed bugs and implemented feature requests",
        "Learned SEO optimization techniques",
      ],
    },
    {
      title: "Freelance WordPress Developer",
      company: "Self-Employed",
      period: "2018 - Present",
      description:
        "Built custom solutions for diverse clients ranging from startups to established businesses. Maintained 98% client satisfaction.",
      responsibilities: [
        "Developed custom WordPress solutions",
        "Handled complete project lifecycle from discovery to deployment",
        "Provided technical support and consulting",
      ],
    },
  ]

  return (
    <section id="experience" className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Experience & Timeline
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto rounded-full" />
        </div>

        <div ref={ref} className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 via-purple-500 to-pink-500 transform md:-translate-x-1/2" />

          {/* Timeline items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div
                key={index}
                className={`md:flex transition-all duration-500 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{
                  transitionDelay: isVisible ? `${index * 100}ms` : "0ms",
                  flexDirection: index % 2 === 0 ? "row" : "row-reverse",
                }}
              >
                {/* Left/Right Content */}
                <div
                  className={`flex-1 ${index % 2 === 0 ? "md:pr-8 md:text-right" : "md:pl-8 md:text-left"} pl-16 md:pl-0`}
                >
                  <div className="relative">
                    {/* Timeline dot */}
                    <div className="absolute left-[-2.75rem] md:left-auto top-1 w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full border-4 border-background flex items-center justify-center md:translate-x-1/2">
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h10a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7zM9 5h2v3H9V5zm-4 9v2h8v-2H5z" />
                      </svg>
                    </div>

                    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6 hover:border-white/30 transition-all duration-300">
                      <div className="flex items-start gap-3 mb-3">
                        <h3 className="text-xl font-bold text-white">{exp.title}</h3>
                      </div>
                      <p className="text-blue-300 font-semibold mb-1">{exp.company}</p>
                      <div className="flex items-center gap-2 text-sm text-foreground/60 mb-4">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                          />
                        </svg>
                        {exp.period}
                      </div>
                      <p className="text-foreground/70 mb-3">{exp.description}</p>
                      <ul className="space-y-2">
                        {exp.responsibilities.map((resp, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-foreground/60">
                            <span className="text-purple-400 mt-1">▸</span>
                            {resp}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Right/Left Spacer */}
                <div className="hidden md:block md:flex-1" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Experience
