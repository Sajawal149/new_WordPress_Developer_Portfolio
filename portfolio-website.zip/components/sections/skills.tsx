"use client"

import { useEffect, useRef, useState } from "react"

const Skills = () => {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.3 },
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const skillCategories = [
    {
      title: "WordPress Core",
      skills: ["Theme Development", "Plugin Development", "WordPress CLI", "REST API"],
      color: "from-blue-500",
    },
    {
      title: "Page Builders",
      skills: ["Elementor", "Divi", "Gutenberg Block Editor", "ACF Pro"],
      color: "from-purple-500",
    },
    {
      title: "E-Commerce",
      skills: ["WooCommerce", "Payment Gateway Integration", "Inventory Management", "Conversion Optimization"],
      color: "from-pink-500",
    },
    {
      title: "Frontend",
      skills: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      color: "from-emerald-500",
    },
    {
      title: "Backend",
      skills: ["PHP", "MySQL", "Database Design", "Security Implementation"],
      color: "from-orange-500",
    },
    {
      title: "Soft Skills",
      skills: ["Communication", "Problem Solving", "Project Management", "Client Relations"],
      color: "from-indigo-500",
    },
  ]

  return (
    <section id="skills" className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Skills & Expertise
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto rounded-full" />
        </div>

        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className={`group relative transition-all duration-500 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: isVisible ? `${index * 100}ms` : "0ms" }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-600/10 rounded-2xl blur-xl group-hover:from-blue-500/20 group-hover:to-purple-600/20 transition-all duration-300" />
              <div
                className={`relative bg-gradient-to-br ${category.color}/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 group-hover:border-white/30 transition-all duration-300`}
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className={`p-3 bg-gradient-to-br ${category.color} to-transparent rounded-lg`}>
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-white">{category.title}</h3>
                </div>
                <ul className="space-y-2">
                  {category.skills.map((skill, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-2 text-sm text-foreground/70 group-hover:text-foreground/90 transition-colors"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-blue-400 to-purple-400" />
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 text-center">
          <p className="text-foreground/70 max-w-2xl mx-auto">
            I'm constantly learning and staying updated with the latest WordPress ecosystem tools and best practices. My
            skills are tailored to deliver fast, secure, and scalable solutions for modern web applications.
          </p>
        </div>
      </div>
    </section>
  )
}

export default Skills
