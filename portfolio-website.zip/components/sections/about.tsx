"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

const About = () => {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.3 },
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section id="about" className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">About Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto rounded-full" />
        </div>

        <div ref={ref} className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div
            className={`space-y-6 transition-all duration-1000 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"}`}
          >
            <div className="space-y-2">
              <h3 className="text-4xl font-bold text-white">Sajawal Hussain</h3>
              <p className="text-lg text-blue-400 font-semibold">WordPress Developer & Designer</p>
            </div>

            <div className="space-y-4">
              <h4 className="text-2xl font-bold text-white">Creative WordPress Developer</h4>
              <p className="text-foreground/70 leading-relaxed">
                I'm a passionate WordPress developer with over 5 years of experience building custom, high-performance
                websites. My mission is to help businesses establish a powerful online presence through modern web
                design and development.
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-lg font-semibold text-white">My Philosophy</h4>
              <p className="text-foreground/70">
                I believe in combining beautiful design with solid technical foundations. Every website I build is
                optimized for speed, SEO, and user experience—ensuring your investment delivers real results.
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-lg font-semibold text-white">My Journey</h4>
              <p className="text-foreground/70">
                Started as a freelancer and grew into building custom solutions for small businesses and enterprises. I
                specialize in transforming visions into digital reality using the latest WordPress technologies.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              {["50+ Projects Completed", "30+ Satisfied Clients", "100% On-Time Delivery", "Full-Stack Expert"].map(
                (item, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <svg className="w-5 h-5 text-blue-400 flex-shrink-0 mt-1" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-sm font-medium text-foreground/80">{item}</span>
                  </div>
                ),
              )}
            </div>
          </div>

          {/* Right Visual - Profile Image */}
          <div
            className={`transition-all duration-1000 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative flex justify-center">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 to-purple-600/30 rounded-3xl blur-3xl" />
              <div className="relative bg-white/5 backdrop-blur-md border border-white/20 rounded-3xl p-6 overflow-hidden">
                <Image
                  src="/images/dsc-00534-removebg-preview-20-281-29-20-282-29-20-281-29.png"
                  alt="Sajawal Hussain - WordPress Developer"
                  width={400}
                  height={500}
                  className="rounded-2xl w-full h-auto object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
