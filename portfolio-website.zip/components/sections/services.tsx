"use client"

import { useEffect, useRef, useState } from "react"

const Services = () => {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      { threshold: 0.3 },
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const services = [
    {
      icon: "Code",
      title: "WordPress Development",
      description: "Custom WordPress theme and plugin development tailored to your specific needs.",
      features: ["Custom Themes", "Plugin Development", "API Integration", "Code Optimization"],
      color: "from-blue-500",
    },
    {
      icon: "ShoppingCart",
      title: "WooCommerce Setup",
      description: "Complete e-commerce solutions with WooCommerce integration and optimization.",
      features: ["Store Setup", "Payment Gateway", "Inventory Management", "Conversion Optimization"],
      color: "from-purple-500",
    },
    {
      icon: "Zap",
      title: "Performance Optimization",
      description: "Optimize your WordPress site for speed, SEO, and user experience.",
      features: ["Page Speed Optimization", "Cache Setup", "Image Optimization", "Database Optimization"],
      color: "from-pink-500",
    },
    {
      icon: "Search",
      title: "SEO Optimization",
      description: "SEO-ready WordPress setup to help your site rank higher on search engines.",
      features: ["Technical SEO", "Schema Markup", "Meta Optimization", "Sitemap Setup"],
      color: "from-emerald-500",
    },
    {
      icon: "Wrench",
      title: "Website Maintenance",
      description: "Ongoing support, updates, and maintenance for your WordPress website.",
      features: ["Security Updates", "Plugin Updates", "Backup Management", "Bug Fixes"],
      color: "from-orange-500",
    },
    {
      icon: "Rocket",
      title: "Landing Pages",
      description: "High-converting landing pages designed to maximize your marketing ROI.",
      features: ["Custom Design", "A/B Testing", "CTA Optimization", "Analytics Setup"],
      color: "from-indigo-500",
    },
  ]

  const getIcon = (iconName: string) => {
    const icons: { [key: string]: string } = {
      Code: '<svg class="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M9.4 16.6L4.8 12l4.6-4.6M14.6 16.6l4.6-4.6-4.6-4.6"/></svg>',
      ShoppingCart:
        '<svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>',
      Zap: '<svg class="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 1 0 9.616 2.587L10.5 5H7a1 1 0 00-.82 1.573l2.468 3.534A1 1 0 009 11H5.159a1 1 0 -.962 1.472l2.927 7.538A1 1 0 0 0 8.827 20h11.346a1 1 0 001.005-1.275l-5.839-15.454a1 1 0 00-.93-.725h-.944L11.3 1.046z" clipRule="evenodd"/></svg>',
      Search:
        '<svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>',
      Wrench:
        '<svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>',
      Rocket:
        '<svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>',
    }
    return icons[iconName] || icons["Code"]
  }

  return (
    <section id="services" className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Services I Offer
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto rounded-full" />
        </div>

        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className={`group relative transition-all duration-500 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: isVisible ? `${index * 100}ms` : "0ms" }}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-r ${service.color}/10 to-transparent rounded-2xl blur-xl group-hover:${service.color}/20 transition-all duration-300`}
              />

              <div
                className={`relative bg-gradient-to-br ${service.color}/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 group-hover:border-white/30 transition-all duration-300 h-full flex flex-col`}
              >
                <div
                  className={`w-14 h-14 rounded-lg bg-gradient-to-br ${service.color} to-transparent flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                >
                  <div dangerouslySetInnerHTML={{ __html: getIcon(service.icon) }} />
                </div>

                <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
                <p className="text-foreground/70 mb-6 text-sm leading-relaxed">{service.description}</p>

                <ul className="space-y-2 flex-1">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-foreground/60">
                      <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-blue-400 to-purple-400" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button className="mt-6 w-full py-3 bg-gradient-to-r from-blue-500/20 to-purple-600/20 text-blue-300 rounded-lg hover:from-blue-500/30 hover:to-purple-600/30 transition-all font-medium text-sm">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-600/10 rounded-2xl blur-2xl" />
          <div className="relative bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 text-center">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Ready to Get Started?</h3>
            <p className="text-foreground/70 max-w-2xl mx-auto mb-8">
              Let's discuss your project requirements and find the perfect solution for your business needs.
            </p>
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault()
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
              }}
              className="inline-block px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:scale-105"
            >
              Book a Consultation
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Services
